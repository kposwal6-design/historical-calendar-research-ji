# Historical Calendar Production CV v3

This version adds a real image-processing grid detector using Android Bitmap APIs only (no OpenCV dependency required for the first production pass).

Pipeline:
Photo -> EXIF/orientation-safe decode -> grayscale -> adaptive-ish threshold -> horizontal/vertical projection -> line clustering -> real cell rectangles -> per-cell crop -> ML Kit OCR -> classifier -> verification gate.

Safety:
- It never invents dates or values.
- If grid evidence is weak, detection is BLOCKED.
- STAR is a separate state.
- A cell with multiple/conflicting numeric candidates is BLOCKED.
- Research cannot start until all cells are verified or STAR.
- Rule outputs remain immutable and sequential.

Build:
Use the included GitHub Actions workflow.
