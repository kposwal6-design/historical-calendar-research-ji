plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.historicalcalendar"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.historicalcalendar"
        minSdk = 24
        targetSdk = 35
        versionCode = 30
        versionName = "3.0.0"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.compose.ui:ui:1.7.6")
    implementation("androidx.compose.material3:material3:1.3.1")
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
