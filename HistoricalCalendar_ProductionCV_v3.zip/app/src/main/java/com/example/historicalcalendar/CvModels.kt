package com.example.historicalcalendar

import android.graphics.Rect

enum class CellKind { TWO_DIGIT, STAR, EMPTY, CONFLICT, UNKNOWN }

data class GridCell(
    val row: Int,
    val column: Int,
    val rect: Rect,
    val kind: CellKind = CellKind.UNKNOWN,
    val rawText: String = "",
    val candidates: List<String> = emptyList(),
    val confidence: Float = 0f,
    val verified: Boolean = false
)

data class GridDetection(
    val status: String,
    val rows: Int,
    val columns: Int,
    val cells: List<GridCell>,
    val diagnostics: List<String>
)
