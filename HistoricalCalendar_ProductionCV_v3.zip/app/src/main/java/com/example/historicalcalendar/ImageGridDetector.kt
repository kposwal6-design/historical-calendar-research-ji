package com.example.historicalcalendar

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.max

/**
 * Real bitmap-based grid detector.
 *
 * It uses luminance projections and line clustering. This is intentionally
 * conservative: weak or incomplete evidence produces BLOCKED rather than
 * synthesizing a calendar.
 */
class ImageGridDetector {

    data class Config(
        val maxDimension: Int = 1800,
        val darkThreshold: Int = 150,
        val lineRatio: Float = 0.42f,
        val minLineSeparationRatio: Float = 0.006f
    )

    fun detect(input: Bitmap, config: Config = Config()): GridDetection {
        val bitmap = scaleDown(input, config.maxDimension)
        val w = bitmap.width
        val h = bitmap.height

        val gray = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val p = bitmap.getPixel(x, y)
            val r = (p shr 16) and 255
            val g = (p shr 8) and 255
            val b = p and 255
            gray[y * w + x] = (299*r + 587*g + 114*b) / 1000
        }

        val horizontal = DoubleArray(h)
        val vertical = DoubleArray(w)

        for (y in 0 until h) {
            var count = 0
            for (x in 0 until w) if (gray[y*w+x] <= config.darkThreshold) count++
            horizontal[y] = count.toDouble() / w
        }
        for (x in 0 until w) {
            var count = 0
            for (y in 0 until h) if (gray[y*w+x] <= config.darkThreshold) count++
            vertical[x] = count.toDouble() / h
        }

        val hs = clusterPeaks(horizontal, config.lineRatio, max(3, (h*config.minLineSeparationRatio).toInt()))
        val vs = clusterPeaks(vertical, config.lineRatio, max(3, (w*config.minLineSeparationRatio).toInt()))

        if (hs.size < 3 || vs.size < 3) {
            return GridDetection("BLOCKED", 0, 0, emptyList(),
                listOf("Grid evidence too weak: H=${hs.size}, V=${vs.size}"))
        }

        val cells = mutableListOf<GridCell>()
        for (r in 0 until hs.size-1) {
            for (c in 0 until vs.size-1) {
                val left = vs[c] + 2
                val top = hs[r] + 2
                val right = vs[c+1] - 2
                val bottom = hs[r+1] - 2
                if (right > left + 10 && bottom > top + 10) {
                    cells += GridCell(r, c, Rect(left, top, right, bottom))
                }
            }
        }

        val rows = hs.size - 1
        val cols = vs.size - 1
        val complete = cells.size == rows * cols
        val status = if (complete) "PASS" else "BLOCKED"

        return GridDetection(status, rows, cols, cells,
            listOf("image=${w}x${h}", "horizontalLines=${hs.size}", "verticalLines=${vs.size}",
                "cells=${cells.size}/$rows*$cols"))
    }

    private fun clusterPeaks(values: DoubleArray, threshold: Float, minSep: Int): List<Int> {
        val peaks = mutableListOf<Int>()
        var start = -1
        for (i in values.indices) {
            val strong = values[i] >= threshold
            if (strong && start < 0) start = i
            if ((!strong || i == values.lastIndex) && start >= 0) {
                val end = if (strong && i == values.lastIndex) i else i-1
                var best = start
                for (j in start..end) if (values[j] > values[best]) best = j
                peaks += best
                start = -1
            }
        }
        val out = mutableListOf<Int>()
        for (p in peaks.sorted()) {
            if (out.isEmpty() || p - out.last() >= minSep) out += p
            else if (values[p] > values[out.last()]) out[out.lastIndex] = p
        }
        return out
    }

    private fun scaleDown(src: Bitmap, maxDim: Int): Bitmap {
        val m = max(src.width, src.height)
        if (m <= maxDim) return src
        val scale = maxDim.toFloat() / m
        return Bitmap.createScaledBitmap(src, (src.width*scale).toInt(), (src.height*scale).toInt(), true)
    }
}
