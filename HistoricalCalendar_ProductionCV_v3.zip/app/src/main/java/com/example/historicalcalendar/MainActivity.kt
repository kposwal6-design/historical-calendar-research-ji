package com.example.historicalcalendar

import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ProductionCvApp() }
    }
}

@Composable
fun ProductionCvApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var uri by remember { mutableStateOf<Uri?>(null) }
    var bitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var detection by remember { mutableStateOf<GridDetection?>(null) }
    var message by remember { mutableStateOf("पहले फोटो अपलोड करें") }
    var ocrDone by remember { mutableStateOf(false) }
    var verified by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        uri = it; detection = null; ocrDone = false; verified = false
        message = if (it == null) "फोटो नहीं चुनी गई" else "फोटो चुनी गई"
    }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Historical Calendar Research") }) }) { pad ->
            LazyColumn(Modifier.padding(pad).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Card {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("STEP 1 — PHOTO UPLOAD")
                            Button(Modifier.fillMaxWidth(), onClick = { picker.launch("image/*") }) {
                                Text("📷 PHOTO UPLOAD")
                            }
                            Text(message)
                        }
                    }
                }
                item {
                    Card {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("STEP 2 — REAL GRID DETECTION")
                            Button(enabled = uri != null, onClick = {
                                scope.launch {
                                    message = "Image पढ़कर वास्तविक grid खोजी जा रही है..."
                                    try {
                                        val u = uri ?: return@launch
                                        val bmp = context.contentResolver.openInputStream(u).use { BitmapFactory.decodeStream(it) }
                                        bitmap = bmp
                                        val d = ImageGridDetector().detect(bmp)
                                        detection = d
                                        message = if (d.status == "PASS")
                                            "Grid PASS: ${d.cells.size} real cells detected"
                                        else "GRID BLOCKED: ${d.diagnostics.joinToString()}"
                                    } catch (e: Exception) {
                                        message = "Image processing error: ${e.message}"
                                    }
                                }
                            }) { Text("🔎 DETECT REAL CALENDAR GRID") }
                            detection?.diagnostics?.forEach { Text("• $it") }
                        }
                    }
                }
                item {
                    Card {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("STEP 3 — BOX-BY-BOX OCR")
                            Button(enabled = detection?.status == "PASS" && bitmap != null, onClick = {
                                scope.launch {
                                    val d = detection ?: return@launch
                                    val bmp = bitmap ?: return@launch
                                    val reader = OcrBoxReader(context)
                                    message = "हर वास्तविक box का OCR चल रहा है..."
                                    var unresolved = 0
                                    for (cell in d.cells) {
                                        val r = reader.read(bmp, cell.rect)
                                        val star = r.raw.contains("★") || r.raw.contains("⭐") || r.raw.trim() == "*"
                                        val valid = r.candidates.size == 1 && r.candidates[0].matches(Regex("\\d{2}"))
                                        if (!star && !valid) unresolved++
                                    }
                                    ocrDone = true
                                    verified = false
                                    message = if (unresolved == 0)
                                        "OCR complete — manual verification/second-pass required before lock"
                                    else
                                        "OCR complete — $unresolved box unresolved; research blocked"
                                }
                            }) { Text("🔍 RUN BOX OCR") }
                            Text("OCR कभी भी अकेले final truth नहीं है.")
                        }
                    }
                }
                item {
                    Card {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("STEP 4 — SAFETY LOCK")
                            when {
                                detection?.status != "PASS" -> Text("🔴 BLOCKED — real grid verified नहीं है.")
                                !ocrDone -> Text("🔴 BLOCKED — box OCR अभी पूरा नहीं हुआ.")
                                !verified -> {
                                    Text("🟡 VERIFY ALL BOXES, फिर LOCK.")
                                    Button(onClick = { verified = true; message = "HISTORY LOCKED" }) {
                                        Text("✅ VERIFY & LOCK")
                                    }
                                }
                                else -> Text("🟢 HISTORY LOCKED — अब sequential Rules को data दिया जा सकता है.")
                            }
                        }
                    }
                }
            }
        }
    }
}
