package com.example.historicalcalendar

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

data class BoxOcr(
    val raw: String,
    val candidates: List<String>,
    val confidence: Float
)

class OcrBoxReader(private val context: Context) {
    suspend fun read(bitmap: Bitmap, rect: Rect): BoxOcr =
        suspendCancellableCoroutine { cont ->
            val safe = Rect(
                rect.left.coerceAtLeast(0),
                rect.top.coerceAtLeast(0),
                rect.right.coerceAtMost(bitmap.width),
                rect.bottom.coerceAtMost(bitmap.height)
            )
            if (safe.width() <= 2 || safe.height() <= 2) {
                cont.resume(BoxOcr("", emptyList(), 0f)); return@suspendCancellableCoroutine
            }
            val crop = Bitmap.createBitmap(bitmap, safe.left, safe.top, safe.width(), safe.height())
            val image = InputImage.fromBitmap(crop, 0)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(image)
                .addOnSuccessListener { result ->
                    val raw = result.text.trim()
                    val candidates = Regex("(?<!\\d)\\d{2}(?!\\d)")
                        .findAll(raw).map { it.value }.distinct().toList()
                    // ML Kit does not expose a reliable per-character probability in this API.
                    // Therefore confidence is conservative and must not auto-lock a cell.
                    val conf = if (candidates.size == 1) 0.90f else 0.50f
                    cont.resume(BoxOcr(raw, candidates, conf))
                }
                .addOnFailureListener { cont.resume(BoxOcr("", emptyList(), 0f)) }
        }
}
